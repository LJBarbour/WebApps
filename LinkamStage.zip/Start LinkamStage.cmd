@echo off
rem ===========================================================================
rem  Start LinkamStage
rem
rem  Serves THIS folder on a local web address and opens the app there.
rem
rem  Why bother, when the .html opens on its own? A page opened as a file has
rem  no address, and a browser files camera permission (and saved settings)
rem  under an address. No address, nothing to file it under, so it asks again
rem  on every single load. Served from localhost it asks once, ever.
rem
rem  SELF-CONTAINED ON PURPOSE. The web server is the PowerShell at the bottom
rem  of this same file, so the only two things that need to travel together
rem  are this .cmd and LinkamStage.html, in the same folder. Nothing else.
rem
rem  The PowerShell is copied out to a plain .ps1 in TEMP and run with -File.
rem  It used to be handed to PowerShell inline, with PowerShell reading this
rem  file and calling Invoke-Expression on the tail of it. That works, but a
rem  command line that reads a file and executes its contents is exactly what
rem  a malicious script looks like, and antivirus refuses to create such a
rem  process at all -- which cmd reports, unhelpfully, as "Access is denied".
rem  Extracting first makes the command line an ordinary, dull one.
rem ===========================================================================

setlocal
set "LSROOT=%~dp0"
set "LSPORT=8793"

rem Which browser to open. "chrome", "edge", or "default" to let Windows
rem decide. Windows keeps the .html file association and the http: association
rem as two separate settings, so "it opens in Chrome when I double-click the
rem file" says nothing about where a http:// address goes -- and camera
rem permission and saved settings are per-browser, so landing in a different
rem one means granting again and keeping a second pile of preferences.
set "LSBROWSER=chrome"

rem "app" opens a plain window with no tab strip, no address bar and no
rem new-tab button -- Ctrl+T does nothing in one -- which suits a machine
rem that is driving an instrument. "tab" opens an ordinary browser tab.
rem Either way it is the same browser profile, so the camera permission and
rem the saved settings are the same ones. Note that this tidies the window;
rem it does not lock the machine down: Ctrl+N still opens a normal window.
rem Real lockdown is Chrome enterprise policy or Windows assigned access.
set "LSWINDOW=app"


rem Already serving on the usual port? Then just open the page.
netstat -ano | findstr /r /c:"LISTENING" | findstr /c:":%LSPORT% " >nul 2>&1
if not errorlevel 1 (
  call :openurl "http://localhost:%LSPORT%/"
  exit /b 0
)

rem --- copy the server out to its own file ------------------------------------
rem findstr /n numbers every line, blank ones included, as  N:text  -- so blank
rem lines survive, which a bare "for /f" would silently drop. Delayed expansion
rem is what keeps  & | > ^  inside the PowerShell from being read as cmd syntax.
set "LSPS1=%TEMP%\LinkamStage_server.ps1"
if exist "%LSPS1%" del "%LSPS1%" >nul 2>&1

setlocal enabledelayedexpansion
set "LSCOPY="
for /f "usebackq delims=" %%L in (`findstr /n "^" "%~f0"`) do (
  set "LSLN=%%L"
  set "LSLN=!LSLN:*:=!"
  if defined LSCOPY (
    echo(!LSLN!>>"%LSPS1%"
  ) else (
    if "!LSLN!"=="#===PS===" set "LSCOPY=1"
  )
)
endlocal

if not exist "%LSPS1%" goto :noextract

echo Starting LinkamStage. Close this window to stop the server.
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%LSPS1%"
if errorlevel 1 goto :psfailed
exit /b 0

rem Open a URL in LSBROWSER if it can be found, else let Windows decide.
rem
rem No parenthesised if-blocks here, deliberately. %ProgramFiles(x86)% has a
rem closing bracket in the middle of it, and cmd finds the end of a block
rem before it expands anything -- so that bracket ends the block early and
rem the rest of it silently does nothing. Hoisting it into a plain variable
rem first, and branching with goto, keeps brackets out of the way entirely.
:openurl
set "LSEXE="
set "LSPF86=%ProgramFiles(x86)%"
if /i "%LSBROWSER%"=="edge" goto :ou_edge
if /i not "%LSBROWSER%"=="chrome" goto :ou_open
call :tryexe "%ProgramFiles%\Google\Chrome\Application\chrome.exe"
call :tryexe "%LSPF86%\Google\Chrome\Application\chrome.exe"
call :tryexe "%LocalAppData%\Google\Chrome\Application\chrome.exe"
goto :ou_open

:ou_edge
call :tryexe "%LSPF86%\Microsoft\Edge\Application\msedge.exe"
call :tryexe "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"

:ou_open
if not defined LSEXE goto :ou_default
if /i "%LSWINDOW%"=="app" start "" "%LSEXE%" --app=%~1
if /i not "%LSWINDOW%"=="app" start "" "%LSEXE%" %1
goto :eof

rem Windows chose the browser, so there is no telling it how to open.
:ou_default
start "" %1
goto :eof

:tryexe
if defined LSEXE goto :eof
if exist "%~1" set "LSEXE=%~1"
goto :eof

:noextract
echo.
echo LinkamStage could not write its server to:
echo     %LSPS1%
echo.
echo That folder is normally writable by everyone. If it is not, set TEMP to
echo somewhere you can write and run this again.
echo.
pause
exit /b 1

:psfailed
echo.
echo PowerShell exited with an error - see the messages above.
echo.
echo If nothing at all was printed above, PowerShell was stopped before it
echo could start. Check whether antivirus has quarantined:
echo     %LSPS1%
echo.
pause
exit /b 1

#===PS===
# --- the web server ---------------------------------------------------------
# Serves the folder the .cmd sits in, on the first port it can bind.

# A drive root needs care: "D:\".TrimEnd('\') is "D:", which Windows reads as
# "the current directory on D:", not the root of D:. GetFullPath keeps it a
# real path either way.
$root = [IO.Path]::GetFullPath($env:LSROOT)
$rootCmp = $root.TrimEnd('\')
if ($rootCmp.Length -eq 2 -and $rootCmp[1] -eq ':') { $rootCmp = $root }   # D:\ stays D:\

# Windows reserves whole blocks of ports (Hyper-V, WSL, Docker and friends),
# and a reserved one refuses to bind with "Access is denied" even though
# nothing is listening on it. So try several rather than insisting on one.
$ports = @()
if ($env:LSPORT) { $ports += [int]$env:LSPORT }
$ports += 8794, 8891, 9123, 9787, 18793

$listener = $null
$port = $null
$errors = @()
foreach ($p in $ports) {
  $l = New-Object System.Net.HttpListener
  $l.Prefixes.Add("http://localhost:$p/")
  try {
    $l.Start()
    $listener = $l
    $port = $p
    break
  } catch {
    $errors += "  port ${p}: $($_.Exception.Message)"
    try { $l.Close() } catch {}
  }
}

if (-not $listener) {
  Write-Host ""
  Write-Host "LinkamStage could not open a local web address." -ForegroundColor Red
  Write-Host ""
  Write-Host "Tried:"
  $errors | ForEach-Object { Write-Host $_ }
  Write-Host ""
  Write-Host "'Access is denied' usually means Windows has reserved that port for"
  Write-Host "something else (Hyper-V, WSL and Docker each reserve large blocks)."
  Write-Host "To see the reserved ranges, run in a normal command prompt:"
  Write-Host ""
  Write-Host "    netsh int ipv4 show excludedportrange protocol=tcp"
  Write-Host ""
  Write-Host "Then set a port outside those ranges: edit this file and change the"
  Write-Host "line   set `"LSPORT=8793`"   near the top."
  Write-Host ""
  Write-Host "Press Enter to close."
  [void](Read-Host)
  exit 1
}

$url = "http://localhost:$port/"
Write-Host "LinkamStage: serving $root"
Write-Host "             on $url"

# Which browser gets the page. Start-Process on a URL hands it to whatever
# holds the http: association, and that is a different Windows setting from
# the .html file association -- so the file and the address can, and do, open
# in different browsers. Camera permission and saved settings are per-browser,
# so that is not cosmetic: it means granting twice and keeping two separate
# piles of preferences. LSBROWSER at the top of the .cmd settles it.
function Find-Browser($which) {
  if (-not $which -or $which -eq 'default') { return $null }
  $exe = 'chrome.exe'
  if ($which -eq 'edge') { $exe = 'msedge.exe' }
  foreach ($hive in 'HKLM:', 'HKCU:') {
    $k = Join-Path $hive "SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\$exe"
    try {
      $v = (Get-ItemProperty -Path $k -ErrorAction Stop).'(default)'
      if ($v -and (Test-Path -LiteralPath $v)) { return $v }
    } catch {}
  }
  $guesses = @("$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
               "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
               "$env:LocalAppData\Google\Chrome\Application\chrome.exe")
  if ($which -eq 'edge') {
    $guesses = @("${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe",
                 "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe")
  }
  foreach ($g in $guesses) { if (Test-Path -LiteralPath $g) { return $g } }
  return $null
}

$browser = Find-Browser $env:LSBROWSER
if ($browser) {
  # --app is a window with no tab strip and no address bar; see LSWINDOW.
  $how = "in a tab"
  $bargs = @($url)
  if ($env:LSWINDOW -eq "app") { $how = "as an app window"; $bargs = @("--app=$url") }
  Write-Host "             in $([IO.Path]::GetFileName($browser)) $how"
  Start-Process -FilePath $browser -ArgumentList $bargs
} else {
  if ($env:LSBROWSER -and $env:LSBROWSER -ne 'default') {
    Write-Host "             ($env:LSBROWSER not found - using the default browser)"
  }
  Start-Process $url
}
Write-Host "Close this window to stop the server."

# "/" goes to LinkamStage.html when it is there, otherwise the first .html in
# the folder -- so a renamed copy still opens without editing anything.
$home_page = 'LinkamStage.html'
if (-not (Test-Path (Join-Path $root $home_page))) {
  $first = Get-ChildItem -LiteralPath $root -Filter *.html -File | Select-Object -First 1
  if ($first) { $home_page = $first.Name }
}

$mime = @{
  '.html'='text/html'; '.htm'='text/html'; '.js'='application/javascript'; '.css'='text/css'
  '.json'='application/json'; '.txt'='text/plain'; '.csv'='text/csv'; '.md'='text/plain'
  '.png'='image/png'; '.jpg'='image/jpeg'; '.jpeg'='image/jpeg'; '.gif'='image/gif'
  '.svg'='image/svg+xml'; '.webp'='image/webp'; '.ico'='image/x-icon'
  '.mp4'='video/mp4'; '.webm'='video/webm'; '.wasm'='application/wasm'
  '.woff'='font/woff'; '.woff2'='font/woff2'; '.pdf'='application/pdf'
}

while ($listener.IsListening) {
  $ctx = $listener.GetContext()
  $req = $ctx.Request
  $res = $ctx.Response
  try {
    $path = [System.Uri]::UnescapeDataString($req.Url.AbsolutePath)
    if ($path -eq '/') { $path = "/$home_page" }
    $rel = ($path -replace '^/', '') -replace '/', '\'
    $full = Join-Path $root $rel

    # never serve anything outside this folder
    $ok = $false
    try {
      $resolved = (Resolve-Path -LiteralPath $full -ErrorAction Stop).Path
      $ok = $resolved.StartsWith($rootCmp, [System.StringComparison]::OrdinalIgnoreCase)
    } catch { $ok = $false }

    if ($ok -and (Test-Path -LiteralPath $resolved -PathType Leaf)) {
      $ext = [System.IO.Path]::GetExtension($resolved).ToLower()
      $ct = $mime[$ext]
      if (-not $ct) { $ct = 'application/octet-stream' }
      $bytes = [System.IO.File]::ReadAllBytes($resolved)
      $res.ContentType = $ct
      $res.Headers.Add('Cache-Control', 'no-store')
      $res.ContentLength64 = $bytes.Length
      $res.OutputStream.Write($bytes, 0, $bytes.Length)
    } else {
      $res.StatusCode = 404
      $buf = [System.Text.Encoding]::UTF8.GetBytes("Not found: $path")
      $res.OutputStream.Write($buf, 0, $buf.Length)
    }
  } catch {
    try { $res.StatusCode = 500 } catch {}
  } finally {
    try { $res.OutputStream.Close() } catch {}
  }
}
